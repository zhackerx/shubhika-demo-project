﻿/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cosmosapi.Controllers
{
    public class ValuesController
    {
    }
}
*/
using cosmosapi.Models;
using cosmosapi.Service;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Cosmos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace cosmosapi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {
        private readonly ICosmosDbService _cosmosDbService;
        public ValuesController(ICosmosDbService cosmosDbService)
        {
            _cosmosDbService = cosmosDbService;
        }

        private static readonly string _endpointUri = "https://7eb57780-0ee0-4-231-b9ee.documents.azure.com:443/";
        private static readonly string _primaryKey = "My8UUsFHmYyVR8175OKuktdGDnp24qQLVLCbHe7u5zKoWJuZjmmvvJm75Fw1j9zSa5Xexm0MrAyceRFSybQAIw==";
        // GET: api/<ValuesController>
        [HttpGet]
        public async Task<Record> Get(string icdcode)
        {
            Record rec = new Record();
            //  var ab = await _cosmosDbService.GetItemsAsync("SELECT * FROM c where c.icdcode='Q00-Q99'");

            using (CosmosClient client = new CosmosClient(_endpointUri, _primaryKey))
            {
                var targetDatabase = client.GetDatabase("healthdb");
                var customContainer = targetDatabase.GetContainer("CustomCollection");
                var container = client.GetContainer("healthdb", "document-record");
                var query = container.GetItemQueryIterator<document_record>(new QueryDefinition("SELECT * FROM c where c.icdcode='" + icdcode + "'"));
                List<document_record> results = new List<document_record>();
                while (query.HasMoreResults)
                {
                    var response = await query.ReadNextAsync();

                    results.AddRange(response.ToList());
                }


                var container1 = client.GetContainer("healthdb", "doctor-record");
                var query1 = container1.GetItemQueryIterator<doctor_record>(new QueryDefinition("SELECT * FROM c where c.icdcode='" + icdcode + "'"));
                List<doctor_record> results1 = new List<doctor_record>();
                while (query1.HasMoreResults)
                {
                    var response = await query1.ReadNextAsync();

                    results1.AddRange(response.ToList());
                }


                var container2 = client.GetContainer("healthdb", "icd-record");
                var query2 = container2.GetItemQueryIterator<icd_record>(new QueryDefinition("SELECT * FROM c where c.icdcode='" + icdcode + "'"));
                List<icd_record> results2 = new List<icd_record>();
                while (query2.HasMoreResults)
                {
                    var response = await query2.ReadNextAsync();

                    results2.AddRange(response.ToList());
                }

                var container3 = client.GetContainer("healthdb", "patient-record");
                var query3 = container3.GetItemQueryIterator<patient_record>(new QueryDefinition("SELECT * FROM c where c.icdcode='" + icdcode + "'"));
                List<patient_record> results3 = new List<patient_record>();
                while (query3.HasMoreResults)
                {
                    var response = await query3.ReadNextAsync();

                    results3.AddRange(response.ToList());
                }

                rec = new Record
                {
                    document_record = results,
                    doctor_record = results1,
                    icd_record = results2,
                    patient_record = results3
                };
            }
            return rec;
        }


    }
}
