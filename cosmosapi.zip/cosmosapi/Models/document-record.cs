﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cosmosapi.Models
{
    public class Record
    {
        public List<document_record> document_record { get; set; }
        public List<doctor_record> doctor_record { get; set; }
        public List<icd_record> icd_record { get; set; }
        public List<patient_record> patient_record { get; set; }


    }
    public class document_record
    {
        public string id { get; set; }
        public string Icdcode { get; set; }
        public string doctor_id { get; set; }
        public string patient_id { get; set; }
        public string dateofappointment { get; set; }
        public string notes { get; set; }


    }
    public class doctor_record
    {
        public string id { get; set; }
        public string name { get; set; }
        public string age { get; set; }
        public string specialization { get; set; }
        public string icdcode { get; set; }
        public string gebder { get; set; }
        public string phone { get; set; }
    }

    public class icd_record
    {
        public string id { get; set; }
        public string description { get; set; }
        public string icdcode { get; set; }

    }
    public class patient_record
    {
        public string id { get; set; }
        public string name { get; set; }
        public string age { get; set; }
        public string gebder { get; set; }
        public string phone { get; set; }
        public string icdcode { get; set; }
        public string address { get; set; }

    }
}
