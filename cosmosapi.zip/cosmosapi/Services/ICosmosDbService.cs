﻿/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cosmosapi.Services
{
    public class CosmosDbService
    {
    }
}
*/
using cosmosapi.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace cosmosapi.Service
{
    public interface ICosmosDbService
    {
        Task<IEnumerable<document_record>> GetItemsAsync(string query);
    }
}