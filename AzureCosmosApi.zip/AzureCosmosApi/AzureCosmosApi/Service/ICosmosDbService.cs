﻿using AzureCosmosApi.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AzureCosmosApi.Service
{
    public interface ICosmosDbService
    {
        Task<IEnumerable<document_record>> GetItemsAsync(string query);
    }
}
